import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        System.out.print("Enter the size of the array: ");
        int n = scan.nextInt();
        int[] a = new int[n];
        System.out.println("Enter the elements of the array:");
        for (int i = 0; i < n; i++) {
            a[i] = scan.nextInt();
        }
        System.out.print("Enter the element to insert at the end: ");
        int newElement = scan.nextInt();
        int[] newArray = new int[n + 1];
        newArray[n] = newElement;
        for (int i = 0; i < n; i++) {
            newArray[i] = a[i];
        }
        //newArray[n] = newElement;
        System.out.println("Array after insertion at the end:");
        for (int num : newArray) {
            System.out.println(num);
        }
        System.out.print("Enter the element to find its position: ");
        int searchElement = scan.nextInt();

        int position = -1;
        for (int i = 0; i < newArray.length; i++) {
            if (newArray[i] == searchElement) {
                position = i;
                break;
            }
        }
        if (position != -1) {
            System.out.println("Element " + searchElement + " found at position: " + position);
        } else {
            System.out.println("Element " + searchElement + " not found.");
        }

        scan.close();
    }
}
