import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        System.out.print("Enter the size of the array: ");
        int n = scan.nextInt();
        int[] a = new int[n];
        System.out.println("Enter the elements of the array:");
        for (int i = 0; i < n; i++) {
            a[i] = scan.nextInt();
        }
        System.out.print("Enter the element to delete: ");
        int elementToDelete = scan.nextInt();
        boolean found = false;
        for (int i = 0; i < n; i++) {
            if (a[i] == elementToDelete) {
                for (int j = i; j < n - 1; j++) {
                    a[j] = a[j + 1];
                }
                found = true;
                n--;
                break;
            }
        }
        if (found) {
            System.out.println("Array after deletion:");
            for (int i = 0; i < n; i++) {
                System.out.println(a[i]);
            }
        } else {
            System.out.println("Element not found in the array.");
        }
        scan.close();
    }
}
