import java.util.Scanner;
public class Main{
  public static void main(String args[]){
    Scanner scan=new Scanner(System.in);
    System.out.println("Enter the size:");
    int n=scan.nextInt();
    int[] a=new int[n];
    System.out.println("Enter the elements:");
    for(int i=0;i<n;i++){
      a[i]=scan.nextInt();
    }
    System.out.println("Enter the begining elements:");
    int newElement=scan.nextInt();
    int[] newArray=new int[n+1];
    newArray[0]=newElement;
    for(int i=0;i<n;i++){
      newArray[i+1]=a[i];
    }
    System.out.println("New array after insertion:");
    for(int num: newArray){
      System.out.println(num);
    }
    scan.close();
  }
}
  